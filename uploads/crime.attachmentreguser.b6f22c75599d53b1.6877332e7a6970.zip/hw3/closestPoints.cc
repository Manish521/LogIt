#include <iostream>
#include <fstream>
#include <string>
#include <sstream>
#include <algorithm>
#include <array>
#include <cmath>
#include <limits>

using namespace std;

struct Point {
	int x;
	int y;
};

struct Answer {
	double distance = numeric_limits<double>::infinity();
	Point  a;
	Point  b;
};

bool sortByX(const Point &l, const Point &r)     { return l.x < r.x; }
bool sortByY(const Point &l, const Point &r)     { return l.y < r.y; }
bool operator==(const Point &l, const Point &r)  { return l.x == r.x && l.y == r.y; }
bool operator<(const Answer &l, const Answer &r) { return l.distance < r.distance; }

double pDist(Point a, Point b) { return sqrt(pow(a.x - b.x, 2) + pow(a.y - b.y, 2)); }

Answer closestPair(Point points[], Point pointsByY[], int count) {
	
	Answer closest;
    // if our array size is 2 or less (meaning 3 points or less) then compute distance directly
	if (count == 1) {
        closest.distance = pDist(points[0], points[1]);
		closest.a = points[0];
		closest.b = points[1];
	}
	
	else if (count == 2) {

		Answer a1;
		a1.distance = pDist(points[0], points[2]);
 		a1.a = points[0];
		a1.b = points[2];
		
		Answer a2;
		a2.distance = pDist(points[0], points[1]);
		a2.a = points[0];
		a2.b = points[1];

		Answer a3;		
		a3.distance = pDist(points[1], points[2]);
		a3.a = points[1];
		a3.b = points[2];

		if      (a1.distance < a2.distance && a1.distance < a3.distance) { closest = a1; }
		else if (a2.distance < a3.distance)                              { closest = a2; }
		else                                                             { closest = a3; }
    }	
	else {

		// else split our x array into a left and right of roughly equal size
		double l = count;
		int verticalSplit = ceil(l / 2);
		
		int sizeLeft = verticalSplit;
		Point xLeft[sizeLeft];

		int sizeRight = count - verticalSplit;
		Point xRight[sizeRight];
		
		int xlNdx = 0;
		int xrNdx = 0;
		for (int i = 0; i <= count; i++) {
			if (i < sizeLeft) { xLeft[xlNdx++] = points[i]; }
			else              { xRight[xrNdx++] = points[i]; }
		}

		// ... make sure we get our presorted y coords into the left and right splits
		int ylNdx = 0;
		int yrNdx = 0;
		Point yLeft[sizeLeft];
		Point yRight[sizeRight];

		for (int i = 0; i <= count; i++) {
			Point *p = find(xLeft, xLeft + sizeLeft, pointsByY[i]);
		
			if (p != xLeft + sizeLeft) { yLeft[ylNdx++] = pointsByY[i];	}
			else                       { yRight[yrNdx++] = pointsByY[i]; }
		}

        // .... and call our function recursively with the left and right splits
		Answer closestL = closestPair(xLeft, yLeft, --ylNdx);
		Answer closestR = closestPair(xRight, yRight, --yrNdx);

        // pick the smallest distance 
 	    if (closestL < closestR) { closest = closestL; }
 	    else                     { closest = closestR; }
 	    
 	    // now find all points within our closest distance of the division line
 	    double xmid = (points[verticalSplit - 1].x + points[verticalSplit].x) / 2;
 	    double lowX = xmid - closest.distance;
 	    double hiX  = xmid + closest.distance;
 	    
 	    Point yPrime[count];
 	    int ypNdx = 0;

 	    for (int i = 0; i < count; i++) {
 	    	if (pointsByY[i].x >= lowX && pointsByY[i].x <= hiX) { yPrime[ypNdx++] = pointsByY[i]; }
 	    }

 	    // and for each point check if the next 7 are closer than our running closest
 	    for (int i = 0; i < ypNdx - 1; i++) {
 	    	for (int j = i + 1; j < ypNdx && j < i + 8; j++) {
 	    		double deltaP = pDist(yPrime[i], yPrime[j]);
 	    		if (deltaP < closest.distance) {
 	    			closest.distance = deltaP;
 	    			closest.a        = yPrime[i];
 	    			closest.b        = yPrime[j];
 	    		}
 	    	}
 	    } 	    
	}
	return closest;
}

int main(int argc, char *argv[]) {

//	string theFile(argv[1]);
//	cout << "Default run will be with filename of '1000pts.txt' in current directory" << endl;
//	cout << "Please type a different fileanme below if you'd like, else hit <Enter>" << endl;
//	cin >> theFile;
//	cout << "|" << theFile << "|" << endl;
    string theFile = "1000points.txt";
	if (argc < 2) {
		cout << endl << "Running with default filename of '1000pts.txt' in current directory" << endl;
		cout << "If you meant to specify another file please pass it as an argument." << endl;
	}
	else if (argc == 2) { theFile = argv[1]; }
	else {
	cout << endl << "This program only accepts one arg with NO SPACES." << endl;
		cout << "The one word arg specifies the point file in the current directory to run against" << endl;
		cout << "In lieu of valid input I will run against the '1000points.txt' file"<< endl;
		cout << "in the current dir" << endl;
	}

	string   aline;
	
    int count = 0;
    ifstream pointFile;
	pointFile.open(theFile);
	if (pointFile.is_open()){
		while (getline(pointFile, aline)) {
				count++;
		}
	}
	else {
	 cout<< theFile << " not found?!?"<< endl;
	 cout<< "Please specify a file name in the current directory as an argument or leave blank for default of '1000points.txt"<< endl;
	  return(0);
	}
	pointFile.close();

 	Point pointsByX[count];
    int arrSize = sizeof(pointsByX)/sizeof(pointsByX[0]);
 	int i = 0;
	pointFile.open(theFile);	

	if (pointFile.is_open()){
		while (getline(pointFile, aline)) {
				stringstream st(aline);
				st >> pointsByX[i].x >> pointsByX[i].y;
				i++;
		}
	}
	else { cout<< theFile << "not found?!?"<< endl;
	 cout<< "Please specify a file name as an argument or leave blannk for default of '1000points.txt"<< endl;
	 return(0);
	}
    // c++11 guarantees O(n lg n) for "sort"
    // ... so sort points by x coord
 	sort(pointsByX, pointsByX + count, sortByX);
 
 	Point pointsByY[count];
    // sort points by y coord
 	copy(pointsByX, pointsByX + count, pointsByY);	
 	sort(pointsByY, pointsByY + count, sortByY);
    // ... and call the closestPair function above
 	Answer theAnswer = closestPair(pointsByX, pointsByY, count);
 	cout <<"Min Distance is...." << endl;
 	cout << endl << theAnswer.distance << ": (" << theAnswer.a.x << "," << theAnswer.a.y << ") <---> (" <<
 	                                              theAnswer.b.x << "," << theAnswer.b.y << ")" << endl;

}